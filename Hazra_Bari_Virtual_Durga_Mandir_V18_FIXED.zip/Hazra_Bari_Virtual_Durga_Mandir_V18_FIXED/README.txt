HAZRA BARI VIRTUAL DURGA MANDIR 2026 - V18 FIXED

The Shared Mandir Sync message is now informational instead of a warning.
The app works in local shared SQLite mode without Supabase credentials.
If SUPABASE_URL and SUPABASE_ANON_KEY are later added to Streamlit Secrets,
cloud event synchronization activates automatically.

Main file: app.py
Maa image: maa_durga.png
Dependencies: requirements.txt
