import re
import html
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from html.parser import HTMLParser

import requests
import streamlit as st

st.set_page_config(page_title="Hazra Bari Virtual Durga Mandir", page_icon="🪔", layout="wide")

# -------------------- CONSTANTS --------------------
TEMPLE_NAME = "Hazra Bari Virtual Durga Mandir"
TEMPLE_ADDRESS = "Sagarbhanga, Durgapur-11, Paschim Bardhaman, West Bengal - 713211, India"
DRIK_URL = "https://www.drikpanchang.com/panchang/day-panchang.html?geoname-id=1272175"
DRIK_MONTH_URL = "https://www.drikpanchang.com/panchang/month-panchang.html?geoname-id=1272175"

NAVRATRI = [
    ("11 Oct 2026", "Shailputri", "Maroon", "🌺"),
    ("12 Oct 2026", "Brahmacharini", "White", "🌼"),
    ("13 Oct 2026", "Chandraghanta", "Red", "🌹"),
    ("14 Oct 2026", "Kushmanda", "Green", "🌿"),
    ("15 Oct 2026", "Skandamata", "Yellow", "🌼"),
    ("16 Oct 2026", "Katyayani", "Silver", "✨"),
    ("17 Oct 2026", "Kalaratri", "Blue", "🪻"),
    ("18 Oct 2026", "Kalaratri", "Dark Maroon", "🌹"),
    ("19 Oct 2026", "Mahagauri", "Pinkish Red", "🌺"),
    ("20 Oct 2026", "Siddhidatri", "Pinkish Red", "🌸"),
    ("21 Oct 2026", "Vijayadashami", "Festive", "🙏"),
]


def india_now():
    return datetime.now(timezone.utc).astimezone(ZoneInfo("Asia/Kolkata"))


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        value = re.sub(r"\s+", " ", data).strip()
        if value:
            self.parts.append(value)

    def text(self):
        return " ".join(self.parts)


def clean(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def fetch_drik_page(url):
    try:
        response = requests.get(
            url,
            timeout=15,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36"},
        )
        response.raise_for_status()
        parser = TextExtractor()
        parser.feed(response.text)
        return parser.text()
    except Exception as exc:
        return ""


def extract_after(text, labels):
    for label in labels:
        pattern = rf"{re.escape(label)}\s*[:\-]?\s*(.{1,140}?)(?=\s+(?:Tithi|Nakshatra|Yoga|Karana|Sunrise|Sunset|Paksha|Moonrise|Moonset)\b|$)"
        match = re.search(pattern, text, flags=re.I)
        if match:
            return clean(match.group(1))
    return "Data unavailable"


@st.cache_data(ttl=900, show_spinner=False)
def get_panchang():
    text = fetch_drik_page(DRIK_URL)
    if not text:
        return {
            "tithi": "Unable to load live data",
            "nakshatra": "Unable to load live data",
            "paksha": "Durgapur Panchang",
            "sunrise": "See Drik Panchang",
            "sunset": "See Drik Panchang",
        }
    return {
        "tithi": extract_after(text, ["Tithi"]),
        "nakshatra": extract_after(text, ["Nakshatra"]),
        "paksha": extract_after(text, ["Paksha"]),
        "sunrise": extract_after(text, ["Sunrise"]),
        "sunset": extract_after(text, ["Sunset"]),
    }


st.markdown("""
<style>
.block-container {padding-top: 1.2rem; max-width: 1250px;}
.hero {padding: 28px; border-radius: 24px; background: linear-gradient(135deg,#fff1dc,#ffe0b5,#f7c6a0); border:1px solid #e7b56d; box-shadow:0 10px 30px rgba(80,30,10,.12);}
.hero h1 {margin:0; color:#7b1018; font-size:42px;}
.hero p {margin:7px 0 0; color:#5c2b1e; font-size:17px;}
.card {padding:20px; border-radius:18px; background:#fffaf4; border:1px solid #efd7b8; height:100%;}
.card h3 {color:#7b1018; margin-top:0;}
.stat {padding:17px; border-radius:16px; background:#fff7eb; border:1px solid #eed4ae;}
.stat b {display:block; color:#8a121b; font-size:18px; margin-top:5px;}
.small {color:#6f625b; font-size:13px;}
</style>
""", unsafe_allow_html=True)

now = india_now()
st.markdown(
    f"<div class='hero'><h1>🪔 {TEMPLE_NAME}</h1><p>🙏 Digital Darshan • Panchang • Navratri • Puja • Mantra</p><p class='small'>{html.escape(TEMPLE_ADDRESS)}<br>India Standard Time: {now.strftime('%d %B %Y, %I:%M:%S %p')}</p></div>",
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("🛕 Mandir Menu")
    page = st.radio(
        "Open",
        ["Home", "Live Panchang", "Navratri 2026", "Virtual Puja", "Mantra Counter", "Sankalp", "Temple Information"],
    )
    st.divider()
    st.caption("Panchang source: Drik Panchang")
    st.caption("Calculation location: Durgapur, West Bengal")

if page == "Home":
    p = get_panchang()
    st.subheader("🌺 Today's Darshan & Panchang")
    cols = st.columns(4)
    stats = [("🌙 Tithi", p["tithi"]), ("⭐ Nakshatra", p["nakshatra"]), ("☀️ Sunrise", p["sunrise"]), ("🌇 Sunset", p["sunset"])]
    for col, (label, value) in zip(cols, stats):
        with col:
            st.markdown(f"<div class='stat'>{label}<b>{html.escape(value)}</b></div>", unsafe_allow_html=True)

    st.write("")
    a, b, c = st.columns(3)
    with a:
        st.markdown("<div class='card'><h3>🔔 Mandir Bell</h3><p>Ring the virtual temple bell before darshan.</p></div>", unsafe_allow_html=True)
        if st.button("🔔 Ring Bell", use_container_width=True):
            st.balloons()
            st.success("🔔 घंटा नाद — जय माता दी!")
    with b:
        st.markdown("<div class='card'><h3>🪔 Virtual Diya</h3><p>Offer a digital diya at Hazra Bari Mandir.</p></div>", unsafe_allow_html=True)
        if st.button("🪔 Light Diya", use_container_width=True):
            st.success("🪔 Your virtual diya is glowing. Jai Maa Durga!")
    with c:
        st.markdown("<div class='card'><h3>🌸 Pushpanjali</h3><p>Offer flowers with devotion.</p></div>", unsafe_allow_html=True)
        if st.button("🌸 Offer Flowers", use_container_width=True):
            st.success("🌸 पुष्पांजलि offered — Jai Mata Di!")

    st.info("Panchang is calculated for Durgapur, West Bengal through Drik Panchang. The temple address is Sagarbhanga, Durgapur-11.")

elif page == "Live Panchang":
    st.subheader("📜 Live Panchang")
    p = get_panchang()
    cols = st.columns(3)
    data = [("🌙 Tithi", p["tithi"]), ("⭐ Nakshatra", p["nakshatra"]), ("☯️ Paksha", p["paksha"]), ("☀️ Sunrise", p["sunrise"]), ("🌇 Sunset", p["sunset"])]
    for i, (label, value) in enumerate(data):
        with cols[i % 3]:
            st.markdown(f"<div class='stat'>{label}<b>{html.escape(value)}</b></div>", unsafe_allow_html=True)
    st.write("")
    st.link_button("Open Full Drik Panchang", DRIK_URL, use_container_width=True)
    st.caption("Yoga and Karana are intentionally not displayed in this app.")

elif page == "Navratri 2026":
    st.subheader("🌺 Hazra Bari Shardiya Navratri 2026")
    st.write("Custom Hazra Bari observance schedule")
    for date, devi, dress, flower in NAVRATRI:
        st.markdown(f"**{flower} {date} — {devi}**  \nDress: **{dress}**")
        st.divider()

elif page == "Virtual Puja":
    st.subheader("🪔 Virtual Puja Seva")
    puja = st.selectbox("Choose Seva", ["Deep Daan", "Pushpanjali", "108 Naam Smaran", "Maa Durga Aarti", "Bhog Offering"])
    devotee = st.text_input("Devotee Name")
    if st.button("🙏 Offer Seva", type="primary"):
        name = devotee.strip() or "Devotee"
        st.success(f"{name}, your {puja} offering has been recorded for this session. Jai Mata Di!")

elif page == "Mantra Counter":
    st.subheader("📿 108 Mantra Counter")
    if "japa" not in st.session_state:
        st.session_state.japa = 0
    st.metric("Mantra Count", f"{st.session_state.japa}/108")
    x, y = st.columns(2)
    with x:
        if st.button("📿 Chant Once", use_container_width=True):
            st.session_state.japa = min(108, st.session_state.japa + 1)
            st.rerun()
    with y:
        if st.button("🔄 Reset", use_container_width=True):
            st.session_state.japa = 0
            st.rerun()
    st.markdown("### मंत्र")
    st.markdown("**ॐ ऐं ह्रीं क्लीं चामुण्डायै विच्चे।**")
    if st.session_state.japa == 108:
        st.success("🌺 108 repetitions completed. Jai Maa Durga!")

elif page == "Sankalp":
    st.subheader("🙏 Digital Sankalp")
    name = st.text_input("Your Name")
    wish = st.text_area("Sankalp / Prayer")
    if st.button("🪔 Take Sankalp", type="primary"):
        if not name.strip() or not wish.strip():
            st.warning("Please enter your name and prayer.")
        else:
            st.success(f"🙏 Sankalp accepted for {name.strip()}. May Maa Durga bless your prayer.")

else:
    st.subheader("🛕 Temple Information")
    st.markdown(f"**Temple:** {TEMPLE_NAME}")
    st.markdown(f"**Address:** {TEMPLE_ADDRESS}")
    st.markdown("**Panchang location:** Durgapur, West Bengal")
    st.markdown("**Panchang provider:** Drik Panchang")
    st.link_button("Visit Drik Panchang", DRIK_URL)
    st.markdown("### 🌺 Hazra Bari Observance")
    st.write("17 October — Kalaratri")
    st.write("18 October — Kalaratri again")
    st.write("19 October — Mahagauri")
    st.write("20 October — Siddhidatri")

st.divider()
st.caption("© 2026 Hazra Bari Virtual Durga Mandir • Built for devotional virtual darshan")
