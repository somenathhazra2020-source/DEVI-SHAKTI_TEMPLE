HAZRA BARI VIRTUAL DURGA MANDIR 2026 - ADVANCED BUILD

Files:
- app.py
- requirements.txt
- maa_durga.png

Deploy with Streamlit Community Cloud using app.py as the entrypoint.
The app uses SQLite locally for the prototype. Streamlit Cloud's local filesystem is not a permanent production database.
