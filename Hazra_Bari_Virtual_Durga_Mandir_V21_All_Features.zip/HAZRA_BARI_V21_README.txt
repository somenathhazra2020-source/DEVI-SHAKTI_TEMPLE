HAZRA BARI VIRTUAL DURGA MANDIR 2026 — V21

This version extends app(20) with an Advanced Temple Center covering:
- Digital Temple Home / IST / Vaar / Tithi-Nakshatra admin fallback / daily Devi info
- Live Darshan + recorded fallback with admin-configurable embed URL
- Custom Hazra Bari Navratri calendar
- Puja/Aarti in-app reminders
- Advanced 108/1008 Japa counter
- Digital Puja Booking + receipt
- Digital Sankalp card download
- Digital Prasad request
- Devi Granth / knowledge search + bookmarks
- Bhajan/Aarti audio controls
- Temple map/directions via admin-configured address
- User profile/reminders/bookmarks
- Donation intention ledger (no real money charged)
- Virtual Diya + Pushpanjali
- Virtual Aarti with real Aarti audio control
- Temple announcements and devotee counters
- Smart search
- Admin controls for temple address, hours, contact, history, live/recorded video URLs

IMPORTANT:
1. This is still a Streamlit application. Native Android push notifications, real camera live streaming, real-money payments, and exact astronomical Panchang calculations require external services/configuration.
2. For production multi-device persistence, Supabase/Postgres should be used instead of local SQLite.
3. Never put a Supabase secret/service-role key in client-visible code.
4. The existing app(20) features are preserved.
