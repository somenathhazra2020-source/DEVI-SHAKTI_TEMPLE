HAZRA BARI VIRTUAL DURGA MANDIR - APP(10) REBUILT

Main deployment file: app.py
Backup/version copy: app(10).py

Audio behavior:
- Temple bell: YouTube ID 97ACG_aLqtM, plays only after the devotee taps the visual bell.
- Durga Aarti: YouTube ID Kw6J7e8lTDM, plays only after the devotee taps the Aarti control.
- No text-to-speech is used for the bell.

Chadhawa behavior:
- Quantity is respected. If 11 hibiscus are offered, the animation shows 11 individual flowers travelling to Maa.
- The altar then permanently displays the recorded hibiscus total from the shared SQLite temple database.
- Recent offerings are visible in the Live Temple Chadhawa feed.

Important:
- The YouTube recordings remain on YouTube; the app embeds the supplied recordings rather than downloading/re-hosting them.
- Browser audio is started by a user click because browsers block unsolicited autoplay.
