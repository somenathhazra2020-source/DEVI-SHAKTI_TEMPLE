Hazra Bari Virtual Durga Mandir — More Advanced Build

Files:
- app.py
- requirements.txt
- maa_durga.png
- AUDIO_SOURCES.txt

Deploy app.py on Streamlit Community Cloud.
The app streams the bell and Durga Aarti recordings from Wikimedia Commons when the devotee presses the controls.

Important: the current temple-wide Chadhawa feed uses the app's SQLite database. It is shared among users while they are connected to the same running app instance, but Streamlit Cloud local storage is not a permanent multi-server database. For permanent cross-device/cross-restart temple-wide totals, connect Supabase/PostgreSQL later.
