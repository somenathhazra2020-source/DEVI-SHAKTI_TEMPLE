HAZRA BARI DUAL TEMPLE — FULLY DYNAMIC PUJA SCHEDULE BUILD

Main Streamlit file: app2.py
Assets: mahadev_shiva.png
Dependencies: requirements.txt

LIVE PUJA / SEVA SCHEDULE — Durgapur IST
05:00–06:00  Mangal Aarti
06:30–07:00  Shringar Aarti
07:00–11:45  Chadhawa / Seva
11:45–12:15  Bhog Seva
12:15–12:30  Bhog Aarti
12:30–16:30  Japa
16:30–18:30  Chadhawa / Seva
18:30–19:00  Evening Aarti
19:00–21:00  Evening Darshan
21:00–21:15  Sayan Aarti; after completion the temple is closed until next Mangal Aarti.

The app enforces these windows for Aarti, Chadhawa/Seva, Bhog and Japa. Attempts outside the correct period are blocked and the current/next scheduled task is shown.

Temple-specific Chadhawa:
- Maa Durga: Saree, Chunri, 16 Shringar and Devi-specific offerings.
- Mahadev: Belpatra, Bilwa, Dhatura, Dhuti, Gamcha, Dhuti-Gamcha, Rudraksha, Bhasma, Abhishek items and Shiva-specific offerings.

Temple-specific Bhog Seva is included for both temples.

Festival system:
- No standalone Navratri navigation section.
- Shardiya Navratri appears dynamically under Upcoming Festivals from 11 October 2026.
- After completion, the next configured festival automatically moves into the Upcoming list; e.g. Karwa Chauth on 29 October 2026.
- Festival display is date-filtered against the current Durgapur IST date.

Panchang:
- Durgapur live reference pages are used for Panchang data.
- No Swiss Ephemeris / pyswisseph / pysweph / ephem dependency is required.

All wallet, cashback and Seva prices are virtual Mandir credits only and have no cash value.
