Hazra Bari Dual Temple — 135.py

Panchang deployment fix:
- No swisseph/pysweph dependency.
- No ephem dependency.
- No runtime package installation.
- Uses the live Durgapur Panchang reference fetch already implemented in 135.py.
- Compatible with Streamlit Cloud Python 3.14.x.

Main file: 135.py
