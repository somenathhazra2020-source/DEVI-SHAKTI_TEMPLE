# SHAKTI — Hazra Bari Virtual Durga Mandir 2026

Main Streamlit application: `application.py`

## Run
```bash
pip install -r requirements.txt
streamlit run application.py
```

## Included
- Full previous Hazra Bari Virtual Durga Mandir facilities preserved from the complete `app(9).py` base
- SHAKTI application identity and clean main filename `application.py`
- Drik Panchang integration for Tithi, Nakshatra, Paksha, sunrise/sunset and upcoming festivals
- Panchang calculation location: Durgapur, West Bengal
- Temple address: Sagarbhanga, Durgapur-11, Paschim Bardhaman, West Bengal - 713211, India
- Yoga and Karana are not displayed

No `devi.py` or `shakti.py` is required; `application.py` is the main entry point.
