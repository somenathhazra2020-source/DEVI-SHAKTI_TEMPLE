# HAZRA BARI VIRTUAL DURGA MANDIR — SHAKTI APPLICATION

Main Streamlit entry file: `data.py`

This build retains the advanced Mandir features from the previous full application and adds the requested navigation:

Home, Darshan, Calendar, Reminders, Japa, Puja, Sankalp, Prasad, Granth, Bhajan, Map, Donation, Diya, Aarti, Search, Account.

It also displays Drik Panchang data for Durgapur calculation location, including Tithi, Nakshatra, Paksha, Sunrise and Sunset. Yoga and Karana are intentionally not displayed.

Temple location: Sagarbhanga, Durgapur-11, Paschim Bardhaman, West Bengal - 713211, India.
